Because my English not too well, there will have some gramma mistakes or any word mistake is normal.
All calculate were after recalculated because to prevent some calculate errors(rounded decimal) but if it less than three decimal, it will use it, and won't recalculate.
Decimal, if it is repeatly decimal, it will round down at least two(e.g. 2.2222 >> 2.22 / 2.312222 >> 2.3122), if it is long decimal, it will at least show 3, not below 2, if I haven't mistakes.
All rank is follow by the origanal faclist, if I haven't any mistakes.
The faclist format is follow by that list too.
I am not sure it won't have any error and mistakes but the profit is used to referring, all profit and prices is change by region, techs and policies.
All assets prices is follow to IdleCorp Wiki(I have checked, that all are sell prices so if you want to know the buy prices, just 2 times of the sell price, and I won't change any prices in Profit.txt to buy price(include of jet fuel price)).
In Profit.txt, the consumes haven't sum together, if you want to know te total consumes, you sum it together by yourself.
Maybe will have some miss so don't need to supprise.
All numbers won't show as fractions.
You still need to follow to the actual region production modifiers to change.
Hope You will understand how to look Profit.txt
And pay attention, the ratio is "the consumes factorys to the produce factory", please remember.

Profit.txt Format
follow to origanal faclist, with the following format:
```
Profit
<profit>(Produces-Consumes)(pre second)
<the at least factorys(of First Fac) can handle(ratio)>(used to refer)(the ratio of orginal ratio is 1:1 and not really is 1:1 now will show all fac ratio like 1:1:1 or 1:4:1, the ratio of the left of the rightest number is arrange of faclist(mean the consumes list))(the number of ratio is follow the consumes list, and with the "1", the"1" is the fac, the numbers is follow the following First Fac's facs, the least number of the facs is in ratio)
First Fac(just the first builded factory)[The one you need to build but just need one, don't need more than one when build more fac(jusu one/can more than one)]
<all facilities need>(when in 100% speed)
<total lands need>
<profit/land used>(pre land)
--
<by-products>(pre second)(if it have by-product(s))
--
<by-products profit>(pre second)(if it have by-product(s))
--
(Haven't the total profit and total by-products' profit, if you want it, calculate it by yourself)
Asset+(In First Fac(each level of factory(0.5%/level)))
(<profit/fac in First Fac>(per fac))(If more than one fac)
<profit/land used>(pre land)(more)
(Follow the chance b, it will show the profit haven't minus the asset profit)
```



Readme v.1.0
Profit v.1.0
Copyright_Notice v.1.0
IdleCorp Profit v.1.0